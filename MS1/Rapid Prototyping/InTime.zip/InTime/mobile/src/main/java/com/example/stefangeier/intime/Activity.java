package com.example.stefangeier.intime;

import java.util.Date;

/**
 * Created by Stefan Geier on 07.11.2017.
 */


class Activity{

    String activityName;
    Date activityDuration;
    int priority;

    Activity(String activityName, Date activityDuration, int priority){
        this.activityName = activityName;
        this.activityDuration = activityDuration;
        this.priority = priority;
    }
}

