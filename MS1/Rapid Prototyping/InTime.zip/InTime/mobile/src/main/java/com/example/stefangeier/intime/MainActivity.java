package com.example.stefangeier.intime;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private VrsXmlParser parser = new VrsXmlParser();

    int toastDuration = Toast.LENGTH_SHORT;
    private NumberPicker durationHourPicker;
    private NumberPicker durationMinutePicker;
    private NumberPicker priorityPicker;
    String result;
    TextView tv1;


    ArrayList<Activity> activityArrayList = new ArrayList<>();
    ArrayList<Activity> schedule = new ArrayList<>();

    Button button_tpd;
    static final int DIALOG_ID = 0;
    int hourDeadline;
    int minuteDeadline;
    String departureTime = null;
    Date departureHHMM;
    int departureHour = -1;
    int departureMinute = -1;
    String output = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        durationHourPicker = (NumberPicker)findViewById(R.id.activityHourDurationNumberPicker);
        durationHourPicker.setMinValue(0);
        durationHourPicker.setMaxValue(23);
        durationHourPicker.setWrapSelectorWheel(true);

        durationMinutePicker = (NumberPicker)findViewById(R.id.activityMinuteDurationNumberPicker);
        durationMinutePicker.setMinValue(0);
        durationMinutePicker.setMaxValue(59);
        durationMinutePicker.setWrapSelectorWheel(true);

        priorityPicker = (NumberPicker)findViewById(R.id.activityPriorityNumberPicker);
        priorityPicker.setMinValue(0);
        priorityPicker.setMaxValue(5);
        priorityPicker.setWrapSelectorWheel(true);

        showTimePickerDialog();


        tv1=(TextView)findViewById(R.id.textView);
        try {
            InputStream is = getAssets().open("Haltestellenabfahrtsplan.xml");
            List<VrsXmlParser.Entry> list = parser.parse(is);
            departureTime = String.valueOf(list.get(0).departureTime);
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String s = departureTime.substring(departureTime.indexOf("T") + 1, departureTime.indexOf("+"));
        departureHHMM = convertToTime(s.substring(0, 5));
        //tv1.setText(String.valueOf(departureHHMM.getHours()) + ":" + String.valueOf(departureHHMM.getMinutes()));

    }

    public void dialog(View v){
        new AlertDialog.Builder(this)
                .setTitle("Info")
                .setMessage(result)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Yahs", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        sendRequest();
                    }
                }).create().show();
    }

    public void sayText(String saidText){
        Toast toast = Toast.makeText(this, saidText, toastDuration);
        toast.show();
    }

    public void sendRequest(){
      RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://www.google.com";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        result = response.substring(0, 500);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                result = "That didn't work!";
            }
        });
        queue.add(stringRequest);
    }

    public void showTimePickerDialog(){
        button_tpd = (Button)findViewById(R.id.setDeadlineButton);
        button_tpd.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                     showDialog(DIALOG_ID);

                    }
                }
        );
    }

    @Override
    protected Dialog onCreateDialog(int id){
        if(id == DIALOG_ID){
            return new TimePickerDialog(MainActivity.this, kTimePickerListener, hourDeadline, minuteDeadline, true);
        }
        return null;
    }

    protected TimePickerDialog.OnTimeSetListener kTimePickerListener =
            new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int i, int i1) {
                    hourDeadline = i;
                    minuteDeadline = i1;
                }
            };

    public void addActivityToSchedule(View v){


        EditText field1 = (EditText)findViewById(R.id.activityNameEditText);
        String newActivityName = String.valueOf(field1.getText());
        String tmpActivityDuration = String.valueOf(durationHourPicker.getValue()).concat(":").concat(String.valueOf(durationMinutePicker.getValue()));
        Date newActivityDuration = convertToTime(tmpActivityDuration);
        int newActivityPriority = priorityPicker.getValue();


        Activity newActivity = new Activity(newActivityName, newActivityDuration, newActivityPriority);
        activityArrayList.add(newActivity);
        sayText(activityArrayList.get(activityArrayList.size()-1).activityName + " | " + activityArrayList.get(activityArrayList.size()-1).activityDuration.getHours() + ":" + activityArrayList.get(activityArrayList.size()-1).activityDuration.getMinutes());
    }

    public void manageSchedule(View v){
        boolean possible = false;
        Date timeNeeded = new Date();
        timeNeeded.setHours(0);
        timeNeeded.setMinutes(0);

        System.out.println(getCurrentTime());
        //sort activities by priority
        Collections.sort(activityArrayList, new Comparator<Activity>() {
            @Override
            public int compare(Activity o1, Activity o2) {
                return o1.priority < o2.priority ? 1
                        : o1.priority > o2.priority ? -1
                        : 0;
            }
        });
        for (int i = 0; i < activityArrayList.size(); i++){
            timeNeeded = addTime(timeNeeded, activityArrayList.get(i).activityDuration);
        }
        System.out.println("Time needed: " + timeNeeded);
        System.out.println("Done at: " + addTime(getCurrentTime(), timeNeeded));

        //Check whether we are below the deadline or not
        if(convertToMinutes(getCurrentTime()) + convertToMinutes(timeNeeded) < convertToMinutes(departureHHMM)){
        //if (addTime(getCurrentTime(), timeNeeded).compareTo(departureHHMM) > 0){
            possible = true;
            System.out.println("Possible");

            for (int i = 0; i < activityArrayList.size(); i++){
                schedule.add(activityArrayList.get(i));
            }
        } else {
            System.out.println("not possible");
            rearrangeActivityDurations(timeNeeded);
        }

        for (int i = 0; i < activityArrayList.size(); i++){
            schedule.add(activityArrayList.get(i));
        }
        System.out.println("SCHEDULE-SIZE: " + schedule.size());
        for(int i = 0; i < schedule.size(); i++){
            System.out.println("at output");

            output = output.concat(String.valueOf(schedule.get(i).activityName + " | " + schedule.get(i).activityDuration.getHours() + ":" + schedule.get(i).activityDuration.getMinutes()) + "\n");
            tv1.setText(output);

        }
        //sayText(String.valueOf(activityArrayList.get(0).priority) + ", "
        // + String.valueOf(activityArrayList.get(1).priority) + ", "
        // + String.valueOf(activityArrayList.get(2).priority));
    }

    private void rearrangeActivityDurations(Date timeNeeded){
        Date dummyDate = new Date();
        int minutesToWin;
        minutesToWin = convertToMinutes(substractTime(addTime(getCurrentTime(), timeNeeded), departureHHMM));

        while (minutesToWin > 0) {
            for (int i = activityArrayList.size() - 1; i >= 0; i--) {
                    if (activityArrayList.get(i).priority == 1) {
                        dummyDate.setHours(0);
                        dummyDate.setMinutes(10);
                        minutesToWin=minutesToWin - 10;
                    } else if (activityArrayList.get(i).priority == 2) {
                        dummyDate.setHours(0);
                        dummyDate.setMinutes(7);
                        minutesToWin=minutesToWin - 7;
                    } else if (activityArrayList.get(i).priority == 3) {
                        dummyDate.setHours(0);
                        dummyDate.setMinutes(3);
                        minutesToWin=minutesToWin - 3;
                    } else if (activityArrayList.get(i).priority == 4) {
                        dummyDate.setHours(0);
                        dummyDate.setMinutes(1);
                        minutesToWin=minutesToWin - 1;
                    } else {
                        dummyDate.setHours(0);
                        dummyDate.setMinutes(0);
                    }
                    //System.out.println("Zeit vorher: " + activityArrayList.get(i).activityDuration.getHours() + ":" + activityArrayList.get(i).activityDuration.getMinutes());
                activityArrayList.set(i, new Activity(activityArrayList.get(i).activityName,
                            substractTime(activityArrayList.get(i).activityDuration, dummyDate),
                            activityArrayList.get(i).priority));
                //System.out.println("Zeit nachher: " + activityArrayList.get(i).activityDuration.getHours() + ":" + activityArrayList.get(i).activityDuration.getMinutes());
            }
            }
        System.out.println("While left.");
    }



    private static String getValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = nodeList.item(0);
        return node.getNodeValue();
    }

    public Date convertToTime(String timeString){
        Date result = new Date();

        SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm");
        try {
            result =  dateFormat.parse(timeString);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return result;
    }

    private Date addTime(Date before, Date summand){
        Date result = new Date();

        result.setHours(before.getHours() + summand.getHours()%24);
        result.setMinutes(before.getMinutes() + summand.getMinutes()%60);
        //Maybe for hours too...(x+y>24, one day later)
        /*if (before.getMinutes() + summand.getMinutes()>60) {
            result.setHours(result.getHours() + 1);
        }*/

        return result;
    }

    private Date substractTime(Date timeBeingSubstracted, Date timeToSubstract){
        Date result = new Date();

        /*if (timeBeingSubstracted.getMinutes() - timeToSubstract.getMinutes() < 0){
            result.setHours(result.getHours()-1);
            result.setMinutes(60 - (timeBeingSubstracted.getMinutes() - timeToSubstract.getMinutes()));
        } else if(timeBeingSubstracted.getHours() - timeToSubstract.getHours() < 0){
            result.setHours(24 - (timeBeingSubstracted.getHours() - timeToSubstract.getHours()));
            //one day earlier to be implemented
        } else if (timeBeingSubstracted.getMinutes() - timeToSubstract.getMinutes() > 0){
            result.setHours(timeBeingSubstracted.getHours() - timeToSubstract.getHours());
            result.setMinutes(timeBeingSubstracted.getMinutes() - timeToSubstract.getMinutes());
        } else {
            result.setHours(0);
            result.setMinutes(0);
        }*/
        result.setHours(timeBeingSubstracted.getHours() - timeToSubstract.getHours());
        result.setMinutes(timeBeingSubstracted.getMinutes() - timeToSubstract.getMinutes());

        return result;
    }

    private int convertToMinutes(Date time){
        return (time.getHours()*60)+time.getMinutes();
    }

    private Date getCurrentTime(){
        Date currentTime = new Date();
        //currentTime.setHours((currentTime.getHours()+6)%24);
        //currentTime.setMinutes((currentTime.getMinutes())%60);

        currentTime.setHours(17);
        currentTime.setMinutes(30);
        return currentTime;
    }
}